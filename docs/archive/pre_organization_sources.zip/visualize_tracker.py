import os
import cv2
import csv
import torch
import numpy as np
import math
from tqdm import tqdm
from collections import deque

try:
    from student_model import MiniROIUNet
except ImportError:
    print("找不到子模型，請確認引入路徑！")

def get_shuttle_center_local(heatmap):
    max_val = np.max(heatmap)
    if max_val == 0: return 0, 0, 0
    y, x = np.unravel_index(np.argmax(heatmap), heatmap.shape)
    return x, y, max_val

def crop_and_pad(img, center_x, center_y, size):
    h, w = img.shape[:2]
    half = size // 2
    x_min, x_max = int(center_x - half), int(center_x + half)
    y_min, y_max = int(center_y - half), int(center_y + half)

    valid_x_min, valid_x_max = max(0, x_min), min(w, x_max)
    valid_y_min, valid_y_max = max(0, y_min), min(h, y_max)

    cropped = img[valid_y_min:valid_y_max, valid_x_min:valid_x_max]

    if cropped.shape[0] != size or cropped.shape[1] != size:
        padded = np.zeros((size, size, img.shape[2] if len(img.shape)==3 else 1), dtype=img.dtype)
        offset_x = valid_x_min - x_min
        offset_y = valid_y_min - y_min
        padded[offset_y : offset_y + cropped.shape[0], offset_x : offset_x + cropped.shape[1]] = cropped
        return padded, x_min, y_min
    return cropped, x_min, y_min

def init_kalman_filter(init_x, init_y):
    kf = cv2.KalmanFilter(4, 2)
    kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=np.float32)
    kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], dtype=np.float32)
    kf.processNoiseCov = np.eye(4, dtype=np.float32) * 0.1
    kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 0.1
    kf.statePost = np.array([[init_x], [init_y], [0.0], [0.0]], dtype=np.float32)
    return kf

def visualize_tracking():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    video_path = r"dataset\raw\part1\match1\video\1_01_00.mp4" 
    csv_path = r"dataset\raw\part1\match1\csv\1_01_00_ball.csv"
    weights_path = r"checkpoints_v4_student\epoch_30.pth" 

    ground_truth = {}
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        keys = reader.fieldnames
        f_key = 'frame_num' if 'frame_num' in keys else 'Frame'
        v_key = 'visible' if 'visible' in keys else 'Visibility'
        x_key, y_key = ('x', 'y') if 'x' in keys else ('X', 'Y')
        for row in reader:
            if int(row[v_key]) == 1:
                ground_truth[int(row[f_key])] = (float(row[x_key]), float(row[y_key]))

    model = MiniROIUNet().to(device)
    model.load_state_dict(torch.load(weights_path, map_location=device))
    model.eval()

    cap = cv2.VideoCapture(video_path)
    W_orig, H_orig = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    out_video = cv2.VideoWriter("debug_tracking_fixed.mp4", cv2.VideoWriter_fourcc(*'mp4v'), 30, (W_orig, H_orig))
    
    W_train, H_train = 512, 288 
    MOTION_THRESH = 15
    
    frame_queue = deque(maxlen=3)
    for _ in range(2):
        ret, frame = cap.read()
        frame_queue.append(cv2.resize(frame, (W_train, H_train)))

    # ✨ 核心改變：拔除 miss_count，改用單一 bool 狀態
    is_lost = True 
    kf = None
    frame_idx = 2

    print(f"🚀 開始輸出 [極簡固定 ROI 版] 除錯影片...")
    with tqdm(total=total_frames-2) as pbar:
        while True:
            ret, frame = cap.read()
            if not ret: break
            
            display_frame = frame.copy() 
            
            f_resized = cv2.resize(frame, (W_train, H_train))
            frame_queue.append(f_resized)
            img0, img1, img2 = frame_queue[0], frame_queue[1], frame_queue[2]
            
            student_found = False
            final_x_512, final_y_512 = 0, 0
            current_conf = 0.0
            mode_text = ""

            # ==========================================
            # 模式 A: 固定 128x128 追蹤 (無情模式)
            # ==========================================
            if not is_lost and kf is not None:
                predicted_state = kf.predict()
                pred_x, pred_y = int(predicted_state[0, 0]), int(predicted_state[1, 0])
                current_size = 128
                thresh = 0.55 # ✨ 嚴格門檻
                mode_text = f"Fixed ROI {current_size}x{current_size}"

                c0, _, _ = crop_and_pad(img0, pred_x, pred_y, current_size)
                c1, _, _ = crop_and_pad(img1, pred_x, pred_y, current_size)
                c2, _, _ = crop_and_pad(img2, pred_x, pred_y, current_size)
                
                g0 = cv2.cvtColor(c0, cv2.COLOR_BGR2GRAY)
                g1 = cv2.cvtColor(c1, cv2.COLOR_BGR2GRAY)
                _, motion_mask = cv2.threshold(cv2.absdiff(g1, g0), MOTION_THRESH, 255, cv2.THRESH_BINARY)
                motion_mask = motion_mask.astype(np.float32) / 255.0

                imgs = np.concatenate((c0, c1, c2), axis=-1).astype(np.float32) / 255.0
                tensor_x = torch.from_numpy(np.transpose(imgs, (2, 0, 1))).unsqueeze(0).to(device)
                
                with torch.no_grad():
                    heatmap = torch.sigmoid(model(tensor_x)).squeeze().cpu().numpy()
                
                heatmap_masked = heatmap * cv2.resize(motion_mask, (heatmap.shape[1], heatmap.shape[0]))
                lx, ly, current_conf = get_shuttle_center_local(heatmap_masked)
                
                if current_conf >= thresh:
                    gx = pred_x - current_size // 2 + lx
                    gy = pred_y - current_size // 2 + ly
                    kf.correct(np.array([[gx], [gy]], dtype=np.float32))
                    final_x_512, final_y_512 = gx, gy
                    student_found = True
                else:
                    # ✨ 一低於 0.55，直接宣告死亡退回全域，不給 256 救援！
                    is_lost = True
                    
                # 畫 ROI 預測框 
                box_x1 = int((pred_x - current_size//2) * (W_orig/W_train))
                box_y1 = int((pred_y - current_size//2) * (H_orig/H_train))
                box_x2 = int((pred_x + current_size//2) * (W_orig/W_train))
                box_y2 = int((pred_y + current_size//2) * (H_orig/H_train))
                color = (255, 165, 0) if student_found else (0, 0, 255) # 追丟變紅框
                cv2.rectangle(display_frame, (box_x1, box_y1), (box_x2, box_y2), color, 2)

            # ==========================================
            # 模式 B: 嚴格全域搜索 (Threshold 0.62)
            # ==========================================
            if is_lost: # 注意這裡用 if，讓它一斷掉可以在同一幀立刻接上全域
                mode_text = "Global Search"
                g0 = cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)
                g1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
                _, motion_mask = cv2.threshold(cv2.absdiff(g1, g0), MOTION_THRESH, 255, cv2.THRESH_BINARY)
                motion_mask = motion_mask.astype(np.float32) / 255.0

                imgs = np.concatenate((img0, img1, img2), axis=-1).astype(np.float32) / 255.0
                tensor_x = torch.from_numpy(np.transpose(imgs, (2, 0, 1))).unsqueeze(0).to(device)
                
                with torch.no_grad():
                    heatmap = torch.sigmoid(model(tensor_x)).squeeze().cpu().numpy()

                heatmap_masked = heatmap * cv2.resize(motion_mask, (heatmap.shape[1], heatmap.shape[0]))
                heatmap_masked[:60, :] = 0.0 
                
                gx, gy, current_conf = get_shuttle_center_local(heatmap_masked)

                # ✨ 採用你建議的高門檻 0.62！
                if current_conf > 0.62: 
                    kf = init_kalman_filter(gx, gy)
                    final_x_512, final_y_512 = gx, gy
                    is_lost = False
                    student_found = True

            # === 繪圖邏輯 ===
            if frame_idx in ground_truth:
                gt_x, gt_y = ground_truth[frame_idx]
                cv2.circle(display_frame, (int(gt_x), int(gt_y)), 10, (0, 255, 0), 3)

            if student_found:
                pred_x_orig = int(final_x_512 * (W_orig / W_train))
                pred_y_orig = int(final_y_512 * (H_orig / H_train))
                cv2.circle(display_frame, (pred_x_orig, pred_y_orig), 8, (0, 0, 255), -1)
                cv2.putText(display_frame, f"Pred {current_conf:.2f}", (pred_x_orig+10, pred_y_orig), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)

            status_color = (0, 255, 0) if student_found else (0, 0, 255)
            cv2.putText(display_frame, f"Mode: {mode_text}", (30, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)
            cv2.putText(display_frame, f"Conf: {current_conf:.3f}", (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, status_color, 2)
            
            out_video.write(display_frame)
            frame_idx += 1
            pbar.update(1)

    cap.release()
    out_video.release()
    print("✅ 影片輸出完成！請打開 debug_tracking_fixed.mp4 觀看！")

if __name__ == '__main__':
    visualize_tracking()