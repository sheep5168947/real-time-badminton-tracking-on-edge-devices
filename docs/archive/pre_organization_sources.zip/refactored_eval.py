import os
import cv2
import csv
import torch
import numpy as np
import math
from tqdm import tqdm
from collections import deque

try:
    from student_model import MiniROIUNet
except ImportError:
    print("找不到子模型，請確認引入路徑！")

# ==========================================
# 核心工具函數
# ==========================================
def get_shuttle_center_local(heatmap):
    max_val = np.max(heatmap)
    if max_val == 0:
        return 0, 0, 0
    y, x = np.unravel_index(np.argmax(heatmap), heatmap.shape)
    return x, y, max_val

def crop_and_pad(img, center_x, center_y, size):
    h, w = img.shape[:2]
    half = size // 2
    x_min, x_max = int(center_x - half), int(center_x + half)
    y_min, y_max = int(center_y - half), int(center_y + half)

    valid_x_min, valid_x_max = max(0, x_min), min(w, x_max)
    valid_y_min, valid_y_max = max(0, y_min), min(h, y_max)

    cropped = img[valid_y_min:valid_y_max, valid_x_min:valid_x_max]

    if cropped.shape[0] != size or cropped.shape[1] != size:
        padded = np.zeros((size, size, img.shape[2] if len(img.shape)==3 else 1), dtype=img.dtype)
        offset_x = valid_x_min - x_min
        offset_y = valid_y_min - y_min
        padded[offset_y : offset_y + cropped.shape[0], offset_x : offset_x + cropped.shape[1]] = cropped
        return padded, x_min, y_min
    return cropped, x_min, y_min

def init_kalman_filter(init_x, init_y):
    kf = cv2.KalmanFilter(4, 2)
    kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=np.float32)
    kf.transitionMatrix = np.array(
        [[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], dtype=np.float32
    )
    kf.processNoiseCov = np.eye(4, dtype=np.float32) * 0.1
    kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 0.1
    kf.statePost = np.array([[init_x], [init_y], [0.0], [0.0]], dtype=np.float32)
    return kf

def calculate_distance(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

# ==========================================
# 全域常數設定 (對齊論文參數)
# ==========================================
W_TRAIN, H_TRAIN = 512, 288 
ROI_SIZE = 128
MOTION_MASK_THRESH = 15     # 論文中的 T_mask
CONF_THRESH_LOCAL = 0.55    # 局部追蹤的信心度門檻
CONF_THRESH_GLOBAL = 0.62   # 全域搜索的信心度門檻
MAX_MISS_TOLERANCE = 1      # 連續丟失幾幀才觸發全域搜索 (論文中提到的計數器)

# ==========================================
# 評估主程式
# ==========================================
def evaluate_tracker():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    video_path = r"dataset\raw\part1\match1\video\1_01_00.mp4" 
    csv_path = r"dataset\raw\part1\match1\csv\1_01_00_ball.csv"
    weights_path = r"checkpoints_v4_student\epoch_30.pth" 

    if not os.path.exists(video_path):
        print("找不到影片，請確認路徑！")
        return

    # 載入 Ground Truth
    ground_truth = {}
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        keys = reader.fieldnames
        f_key = 'frame_num' if 'frame_num' in keys else 'Frame'
        v_key = 'visible' if 'visible' in keys else 'Visibility'
        x_key, y_key = ('x', 'y') if 'x' in keys else ('X', 'Y')
        for row in reader:
            if int(row[v_key]) == 1:
                ground_truth[int(row[f_key])] = (float(row[x_key]), float(row[y_key]))

    model = MiniROIUNet().to(device)
    model.load_state_dict(torch.load(weights_path, map_location=device))
    model.eval()

    cap = cv2.VideoCapture(video_path)
    W_orig, H_orig = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    frame_queue = deque(maxlen=3)
    predictions = {}
    
    for _ in range(2):
        ret, frame = cap.read()
        if not ret: break
        frame_queue.append(cv2.resize(frame, (W_TRAIN, H_TRAIN)))

    # === 論文狀態機變數 ===
    is_lost = True
    miss_count = 0
    kf = None

    frame_idx = 2
    print("開始進行純淨版雙引擎追蹤評估...")
    with tqdm(total=total_frames-2) as pbar:
        while True:
            ret, frame = cap.read()
            if not ret: break
            
            f_resized = cv2.resize(frame, (W_TRAIN, H_TRAIN))
            frame_queue.append(f_resized)
            
            img0, img1, img2 = frame_queue[0], frame_queue[1], frame_queue[2]
            
            student_found = False
            final_x_512, final_y_512 = 0, 0

            # ==========================================
            # 模式 A: 局部巡航與熱力圖信心度監測 (128x128)
            # ==========================================
            if not is_lost and kf is not None:
                predicted_state = kf.predict()
                pred_x, pred_y = int(predicted_state[0, 0]), int(predicted_state[1, 0])

                c0, _, _ = crop_and_pad(img0, pred_x, pred_y, ROI_SIZE)
                c1, _, _ = crop_and_pad(img1, pred_x, pred_y, ROI_SIZE)
                c2, _, _ = crop_and_pad(img2, pred_x, pred_y, ROI_SIZE)
                
                # 計算動態遮罩
                g0 = cv2.cvtColor(c0, cv2.COLOR_BGR2GRAY)
                g1 = cv2.cvtColor(c1, cv2.COLOR_BGR2GRAY)
                diff = cv2.absdiff(g1, g0)
                _, motion_mask = cv2.threshold(diff, MOTION_MASK_THRESH, 255, cv2.THRESH_BINARY)
                motion_mask = motion_mask.astype(np.float32) / 255.0

                imgs = np.concatenate((c0, c1, c2), axis=-1).astype(np.float32) / 255.0
                tensor_x = torch.from_numpy(np.transpose(imgs, (2, 0, 1))).unsqueeze(0).to(device)
                
                with torch.no_grad():
                    heatmap = torch.sigmoid(model(tensor_x)).squeeze().cpu().numpy()
                
                # 哈達瑪乘積 (物理歸零防禦)
                heatmap_masked = heatmap * cv2.resize(motion_mask, (heatmap.shape[1], heatmap.shape[0]))
                lx, ly, conf = get_shuttle_center_local(heatmap_masked)
                
                if conf >= CONF_THRESH_LOCAL:
                    gx = pred_x - ROI_SIZE // 2 + lx
                    gy = pred_y - ROI_SIZE // 2 + ly
                    
                    kf.correct(np.array([[gx], [gy]], dtype=np.float32))
                    final_x_512, final_y_512 = gx, gy
                    student_found = True
                    miss_count = 0 # 成功鎖定，重置計數器
                else:
                    miss_count += 1
                    
                # 階段二：脫框判定與全域救援觸發
                if miss_count >= MAX_MISS_TOLERANCE:
                    is_lost = True

            # ==========================================
            # 模式 B: 脫框死鎖與全域救援 (512x288)
            # ==========================================
            if is_lost:
                # 計算全域動態遮罩
                g0 = cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)
                g1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
                diff = cv2.absdiff(g1, g0)
                _, motion_mask = cv2.threshold(diff, MOTION_MASK_THRESH, 255, cv2.THRESH_BINARY)
                motion_mask = motion_mask.astype(np.float32) / 255.0

                imgs = np.concatenate((img0, img1, img2), axis=-1).astype(np.float32) / 255.0
                tensor_x = torch.from_numpy(np.transpose(imgs, (2, 0, 1))).unsqueeze(0).to(device)
                
                with torch.no_grad():
                    heatmap = torch.sigmoid(model(tensor_x)).squeeze().cpu().numpy()

                # 哈達瑪乘積 (全域物理歸零防禦)
                heatmap_masked = heatmap * cv2.resize(motion_mask, (heatmap.shape[1], heatmap.shape[0]))
                
                # 🚨 注意：這裡已經徹底刪除 heatmap_masked[:60, :] = 0.0 這個駭客寫法！
                
                gx, gy, conf = get_shuttle_center_local(heatmap_masked)

                # 階段三：目標重獲與物理座標交接
                if conf > CONF_THRESH_GLOBAL:
                    kf = init_kalman_filter(gx, gy) # 重置 KF
                    final_x_512, final_y_512 = gx, gy
                    is_lost = False
                    miss_count = 0
                    student_found = True

            # 紀錄座標
            if student_found:
                pred_x_orig = final_x_512 * (W_orig / float(W_TRAIN))
                pred_y_orig = final_y_512 * (H_orig / float(H_TRAIN))
                predictions[frame_idx] = (pred_x_orig, pred_y_orig)
            
            frame_idx += 1
            pbar.update(1)

    cap.release()

    # 計算成績... (與原版相同，省略印出以節省版面)
    print("\n" + "="*50)
    print("純淨版系統重構完成！可以準備開始產圖了！")

if __name__ == '__main__':
    evaluate_tracker()