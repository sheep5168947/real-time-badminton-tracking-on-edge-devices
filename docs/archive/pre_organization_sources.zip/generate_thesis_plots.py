# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib

# 強制使用 Agg 背景，避免在 Jetson Nano SSH 或無桌面環境下繪圖報錯
# matplotlib.use('Agg')

def main():
    print("[INFO] 載入論文實驗數據...")
    # 確保這兩個檔名與你的 CSV 完全一致
    df_128 = pd.read_csv("hyperparameter_tuning_results_128_batch.csv")
    df_64 = pd.read_csv("hyperparameter_tuning_results_64_4D.csv")

    # ==========================================
    # 圖表一：效能邊界散佈圖 (Pareto Front Scatter Plot)
    # ==========================================
    print("[INFO] 繪製 圖表一：效能邊界散佈圖...")
    fig1, ax1 = plt.subplots(figsize=(10, 6))
    
    # 畫出所有的點
    ax1.scatter(df_128['Average_FPS'], df_128['Precision(%)'], 
                c='royalblue', alpha=0.5, s=60, label='128x128 Engine')
    ax1.scatter(df_64['Average_FPS'], df_64['Precision(%)'], 
                c='crimson', alpha=0.5, s=60, marker='^', label='64x64 Engine')
    
    # 標示出兩者的最佳黃金點
    best_128 = df_128[(df_128['Motion_Thresh']==15) & (df_128['Conf_Local']==0.55) & (df_128['Conf_Global']==0.62) & (df_128['Max_Miss']==1)].iloc[0]
    best_64 = df_64[(df_64['Motion_Thresh']==15) & (df_64['Conf_Local']==0.55) & (df_64['Conf_Global']==0.62) & (df_64['Max_Miss']==2)].iloc[0]
    
    ax1.scatter(best_128['Average_FPS'], best_128['Precision(%)'], c='none', edgecolor='black', linewidths=2, s=200, zorder=5)
    ax1.scatter(best_64['Average_FPS'], best_64['Precision(%)'], c='none', edgecolor='black', linewidths=2, s=200, zorder=5)
    
    ax1.annotate('Best 128x128', (best_128['Average_FPS'], best_128['Precision(%)']), xytext=(-40, -30), textcoords='offset points', arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"))
    ax1.annotate('Best 64x64', (best_64['Average_FPS'], best_64['Precision(%)']), xytext=(20, 10), textcoords='offset points', arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"))
    
    ax1.set_title("Performance Boundary: Inference Speed vs. Precision", fontsize=14, pad=15)
    ax1.set_xlabel("Average FPS", fontsize=12)
    ax1.set_ylabel("Precision (%)", fontsize=12)
    ax1.grid(True, linestyle='--', alpha=0.7)
    ax1.legend(loc='lower right')
    fig1.savefig("figure1_pareto_front.png", dpi=300, bbox_inches='tight')

    # ==========================================
    # 圖表二：控制變因折線圖 (斷崖效應與盲推分析)
    # ==========================================
    print("[INFO] 繪製 圖表二：控制變因折線圖...")
    # 鎖定背景變因：Motion=15, Global=0.62 (拿 64x64 來畫)
    df_line = df_64[(df_64['Motion_Thresh'] == 15) & (df_64['Conf_Global'] == 0.62)]
    
    fig2, ax2 = plt.subplots(figsize=(10, 6))
    colors = ['green', 'darkorange', 'purple']
    markers = ['o', 's', 'D']
    
    for i, miss in enumerate([1, 2, 3]):
        subset = df_line[df_line['Max_Miss'] == miss].sort_values('Conf_Local')
        ax2.plot(subset['Conf_Local'], subset['Precision(%)'], 
                 marker=markers[i], color=colors[i], linewidth=2.5, markersize=8, 
                 label=f'Max Miss = {miss}')
        
    ax2.set_title("Sensitivity Analysis: Local Confidence vs. Max Miss (64x64 ROI)", fontsize=14, pad=15)
    ax2.set_xlabel("Local Confidence Threshold (Conf_Local)", fontsize=12)
    ax2.set_ylabel("Precision (%)", fontsize=12)
    ax2.grid(True, linestyle='--', alpha=0.7)
    ax2.legend(title="Tolerance Level")
    fig2.savefig("figure2_sensitivity_line.png", dpi=300, bbox_inches='tight')

    # ==========================================
    # 圖表三：終極對決群組長條圖 (Ablation Study Summary)
    # ==========================================
    print("[INFO] 繪製 圖表三：終極對決群組長條圖...")
    labels = ['Precision (%)', 'Recall (%)', 'Local Tracking Ratio (%)']
    val_128 = [best_128['Precision(%)'], best_128['Recall(%)'], best_128['Local_Ratio(%)']]
    val_64 = [best_64['Precision(%)'], best_64['Recall(%)'], best_64['Local_Ratio(%)']]
    
    x = np.arange(len(labels))
    width = 0.35
    
    fig3, ax3 = plt.subplots(figsize=(10, 6))
    
    # 畫左側 Y 軸的長條圖 (百分比指標)
    bars1 = ax3.bar(x - width/2, val_128, width, label='Best 128x128', color='royalblue')
    bars2 = ax3.bar(x + width/2, val_64, width, label='Best 64x64', color='crimson')
    
    ax3.set_ylabel('Percentage (%)', fontsize=12)
    ax3.set_title('Ablation Study: Best Configuration Comparison', fontsize=14, pad=15)
    ax3.set_xticks(x)
    ax3.set_xticklabels(labels, fontsize=11)
    ax3.set_ylim(40, 70)  # 縮放 Y 軸讓差異更明顯
    ax3.legend(loc='upper left')
    
    # 加上數值標籤
    for bar in bars1 + bars2:
        height = bar.get_height()
        ax3.annotate(f'{height:.1f}',
                     xy=(bar.get_x() + bar.get_width() / 2, height),
                     xytext=(0, 3), textcoords="offset points",
                     ha='center', va='bottom', fontsize=10)

    # 畫右側 Y 軸 (FPS)
    ax3_twin = ax3.twinx()
    fps_128 = best_128['Average_FPS']
    fps_64 = best_64['Average_FPS']
    
    # 用虛線與大圓點標示 FPS
    ax3_twin.plot([-0.2, 0.2], [fps_128, fps_128], color='darkblue', marker='o', markersize=10, linestyle='None', label='128x128 FPS')
    ax3_twin.plot([2.8, 3.2], [fps_64, fps_64], color='darkred', marker='^', markersize=10, linestyle='None', label='64x64 FPS')
    
    # 畫一條橫跨圖表的隱形趨勢線來連接 FPS 標籤
    ax3_twin.plot([0, 3], [fps_128, fps_64], color='black', linestyle=':', alpha=0.3)
    ax3_twin.text(0, fps_128 + 0.1, f'FPS: {fps_128:.1f}', ha='center', va='bottom', color='darkblue', fontweight='bold')
    ax3_twin.text(3, fps_64 + 0.1, f'FPS: {fps_64:.1f}', ha='center', va='bottom', color='darkred', fontweight='bold')

    ax3_twin.set_ylabel('Average FPS', fontsize=12)
    ax3_twin.set_ylim(8, 12)  # FPS 範圍
    
    fig3.savefig("figure3_ablation_summary.png", dpi=300, bbox_inches='tight')
    
    print("\n========================================")
    print("🏆 圖表生成完成！請查看當前目錄下的三個 .png 檔案：")
    print(" 1. figure1_pareto_front.png (效能邊界散佈圖)")
    print(" 2. figure2_sensitivity_line.png (容錯與信心度折線圖)")
    print(" 3. figure3_ablation_summary.png (最佳參數對比圖)")
    print("========================================")

if __name__ == "__main__":
    main()